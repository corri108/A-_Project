#include "location.h"

location::location(int x, int y)
{
	this->x = x;
	this->y = y;
}

location::~location()
{

}