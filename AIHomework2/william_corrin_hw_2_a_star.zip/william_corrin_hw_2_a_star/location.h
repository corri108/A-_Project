#pragma once
class location
{
public:
	location(int x, int y);
	~location();
	int x = 0;
	int y = 0;
};

