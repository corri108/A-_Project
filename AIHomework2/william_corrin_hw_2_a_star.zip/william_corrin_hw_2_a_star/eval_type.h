#pragma once

enum eval_type
{
	EUCLIDIAN,
	MANHATTAN,
	A_STAR_EUCLIDIAN,
	A_STAR_MANHATTAN
};